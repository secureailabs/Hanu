import RequestProxy from './request-proxy';

export default RequestProxy;
