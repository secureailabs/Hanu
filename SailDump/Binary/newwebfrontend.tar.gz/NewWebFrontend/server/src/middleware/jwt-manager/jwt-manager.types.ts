export type JWTManagerOptionsType = {
  order?: string;
  token?: 'access' | 'refresh';
};
