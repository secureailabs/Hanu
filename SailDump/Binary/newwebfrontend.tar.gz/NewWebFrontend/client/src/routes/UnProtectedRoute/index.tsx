import UnProtectedRouteContainer from './UnProtectedRoute.container';

export default UnProtectedRouteContainer;
