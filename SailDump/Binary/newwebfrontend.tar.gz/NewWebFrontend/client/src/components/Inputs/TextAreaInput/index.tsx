import TextAreaInput from './TextAreaInput.component';
import {TTextAreaInputProps} from './TextAreaInput.types';


export default TextAreaInput;
export type {TTextAreaInputProps};