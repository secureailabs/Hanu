import RadioInput from './RadioInput.component';
import {TRadioInputProps} from './RadioInput.types';


export default RadioInput;
export type {TRadioInputProps};