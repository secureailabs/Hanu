import TextInput from './TextInput.component';
import {TTextInputProps} from './TextInput.types';


export default TextInput;
export type {TTextInputProps};