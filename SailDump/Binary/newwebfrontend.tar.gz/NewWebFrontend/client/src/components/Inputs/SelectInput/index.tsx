import SelectInput from './SelectInput.component';
import {TSelectInputProps} from './SelectInput.types';


export default SelectInput;
export type {TSelectInputProps};