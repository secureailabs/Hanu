import PatientSummary from './PatientSummary.component';

export default PatientSummary;
