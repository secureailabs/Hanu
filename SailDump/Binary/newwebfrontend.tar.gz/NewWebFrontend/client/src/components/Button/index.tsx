import Button from './Button.component';

import type { TButton } from './Button.types';

export type { TButton };
export default Button;
