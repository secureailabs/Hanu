import InfoDisplay from './InfoDisplay.component';

export default InfoDisplay;
