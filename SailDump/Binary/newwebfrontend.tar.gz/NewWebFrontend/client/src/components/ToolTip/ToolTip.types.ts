export type TTooltipProps = {
    tooltiptext?: string;
    icon?: string;
  };