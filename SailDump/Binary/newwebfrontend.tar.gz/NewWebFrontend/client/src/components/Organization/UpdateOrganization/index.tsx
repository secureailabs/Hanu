import UpdateOrganization from "./UpdateOrganization.component";

export default UpdateOrganization;