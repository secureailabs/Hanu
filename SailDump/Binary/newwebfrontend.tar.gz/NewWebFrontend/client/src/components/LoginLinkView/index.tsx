import LoginLinkView from './LoginLinkView.component';

export default LoginLinkView;
