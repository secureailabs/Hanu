export type TLoginLinkView = {
  message: string;
  onClick: () => void;
  buttonText?: string;
};
