import DevMode from './DevMode.component';

export default DevMode;