import Title from './Title.component';

export default Title;
