import LargeLogo from './LargeLogo';

export default LargeLogo;