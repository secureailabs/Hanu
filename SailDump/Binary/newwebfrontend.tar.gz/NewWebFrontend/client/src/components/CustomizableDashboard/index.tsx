import CustomizableDashboard from './CustomizableDashboard.container';

export default CustomizableDashboard;
