import Table from './Table.component';

export default Table;
