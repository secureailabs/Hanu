import FeedContainer from './Feed.component';

export default FeedContainer;
