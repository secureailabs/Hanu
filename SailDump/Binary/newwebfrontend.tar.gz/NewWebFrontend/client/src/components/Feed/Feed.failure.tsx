import React from 'react';

const FeedFailure = () => {
  return <>Failure</>;
};

export default FeedFailure;
