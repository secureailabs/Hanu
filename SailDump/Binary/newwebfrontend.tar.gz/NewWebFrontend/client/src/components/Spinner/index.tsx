import AbsoluteSpinner from './AbsoluteSpinner.component';
import Spinner from './Spinner.component';
import SpinnerOnly from './SpinnerOnly.component';

export default Spinner;
export { AbsoluteSpinner, Spinner, SpinnerOnly };
