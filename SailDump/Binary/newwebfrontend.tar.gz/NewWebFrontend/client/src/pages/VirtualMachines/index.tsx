import VirtualMachines from './VirtualMachines.container';

export default VirtualMachines;
