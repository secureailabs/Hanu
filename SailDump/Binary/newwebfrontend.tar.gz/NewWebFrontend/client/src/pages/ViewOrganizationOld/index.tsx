import ViewOrganization from "./ViewOrganization.component";

export default ViewOrganization;
