import DocumentationContainer from './Documentation.container';

export default DocumentationContainer;
