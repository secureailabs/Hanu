import UnifiedRegistriesContainer from './UnifiedRegistries.component';

export default UnifiedRegistriesContainer;
