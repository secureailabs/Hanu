import UnifiedRegistryContainer from './UnifiedRegistry.component';

export default UnifiedRegistryContainer;
