import ViewOrganizationContainer from './ViewOrganization.component';

export default ViewOrganizationContainer;
