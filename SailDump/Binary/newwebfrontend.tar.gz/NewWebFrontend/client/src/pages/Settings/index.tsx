import SettingsContainer from './Settings.component';

export default SettingsContainer;
