import { IUserData } from '@APIs/user/user.typeDefs';

export type TSettings = {
  userData: IUserData;
};
