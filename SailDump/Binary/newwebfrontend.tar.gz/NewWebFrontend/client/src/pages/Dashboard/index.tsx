import Dashboard from './Dashboard.container';

export default Dashboard;
