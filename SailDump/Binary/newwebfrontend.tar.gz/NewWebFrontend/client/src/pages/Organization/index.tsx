import Organization from './Organization.component';

export default Organization;
