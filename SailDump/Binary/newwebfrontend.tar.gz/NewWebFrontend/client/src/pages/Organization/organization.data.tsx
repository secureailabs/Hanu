export default {
    "OrganizationName": "Data Owner Institution1",
    "OrganizationAddress": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam quia aspernatur unde distinctio reprehenderit saepe omnis, quas sed magnam, error officiis enim doloribus harum? Aliquam ullam magnam nobis tempora nihil?",
    "PrimaryContactName": "123213",
    "PrimaryContactJobTitle": "12312",
    "PrimaryContactEmail": "example@email.com",
    "PrimaryContactPhoneNumber": "1231231",
    "SecondaryContactName": "jhon",
    "SecondaryContactJobTitle": "lorem ipsum",
    "SecondaryContactEmail": "lorem@email.com",
    "SecondaryContactPhoneNumber": "234578"
}