import Download from './Download.container';

export default Download;
