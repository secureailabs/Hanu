import DownloadsContainer from './Downloads.container';

export default DownloadsContainer;
