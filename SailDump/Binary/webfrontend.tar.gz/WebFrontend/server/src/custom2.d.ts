declare namespace Express {
    export interface Response {
      body: any;
    }
    export interface Request {
      body: any;
    }
  }