export type EOSBManagerOptionsType = {
  order?: string;
  token?: string;
};
