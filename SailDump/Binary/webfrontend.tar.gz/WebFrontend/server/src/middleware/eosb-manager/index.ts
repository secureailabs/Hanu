import EOSBManager from './eosb-manager';

export default EOSBManager;
