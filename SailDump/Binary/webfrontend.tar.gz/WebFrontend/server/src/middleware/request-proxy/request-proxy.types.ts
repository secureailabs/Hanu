export type RequestProxyOptionTypes = {
  method?: 'GET' | 'POST' | 'PATCH' | 'DELETE' | 'PUT';
  path?: string;
};
