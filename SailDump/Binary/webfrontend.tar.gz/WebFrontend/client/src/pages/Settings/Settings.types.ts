import { IUserData } from '@redux/user/user.typeDefs';

export type TSettings = {
  userData: IUserData;
};
