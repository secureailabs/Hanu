import SettingsContainer from './Settings.container';

export default SettingsContainer;
