import { IState } from '@redux/root-reducer';

export interface IMainMenu {
  userData: IState['user']['userData'];
}
