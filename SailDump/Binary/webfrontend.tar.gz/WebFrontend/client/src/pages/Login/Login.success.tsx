import React from 'react';

const Login = () => {
  return <></>;
};

export default Login;
