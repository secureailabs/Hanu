import DigitalContracts from './VirtualMachines.container';

export default DigitalContracts;
