import React from 'react';

const LoginFailure = () => {
  return (
    <p>There was an error fetching digital contracts. Please try again later</p>
  );
};

export default LoginFailure;
