import AzureTemplatesManager from './AzureTemplatesManager.container';

export default AzureTemplatesManager;
