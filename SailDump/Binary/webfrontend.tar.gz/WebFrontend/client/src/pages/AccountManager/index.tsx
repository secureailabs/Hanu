import AccountManager from './AccountManager.container';

export default AccountManager;
