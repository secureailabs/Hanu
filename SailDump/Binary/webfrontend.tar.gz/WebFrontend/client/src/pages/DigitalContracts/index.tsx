import DigitalContracts from './DigitalContracts.container';

export default DigitalContracts;
