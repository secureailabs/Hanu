import UnderConstruction from "./UnderConstruction.component";

export default UnderConstruction;