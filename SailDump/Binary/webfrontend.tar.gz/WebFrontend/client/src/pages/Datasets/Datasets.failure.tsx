import React from 'react';

const DatasetsFailure = () => {
  return (
    <p>There was an error fetching datasets. Please try again later</p>
  );
};

export default DatasetsFailure;
