import Datasets from './Datasets.container';

export default Datasets;
