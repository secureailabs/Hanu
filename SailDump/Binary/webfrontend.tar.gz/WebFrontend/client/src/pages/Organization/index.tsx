import Organization from './Organization.container';

export default Organization;
