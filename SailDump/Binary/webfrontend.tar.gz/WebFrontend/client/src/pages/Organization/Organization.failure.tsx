import React from 'react';

const OrganizationFailure = () => {
  return <>Failure</>;
};

export default OrganizationFailure;
