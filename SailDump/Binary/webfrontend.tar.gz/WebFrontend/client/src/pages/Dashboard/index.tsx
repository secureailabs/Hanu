import Dashboard from './Dashboard.component';

export default Dashboard;
