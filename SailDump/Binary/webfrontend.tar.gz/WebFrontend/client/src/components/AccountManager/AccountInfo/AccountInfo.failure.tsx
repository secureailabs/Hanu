import React from 'react';

const AccountInfoFailure = () => {
  return <p>There was an error fetching user details, please try again later.</p>;
};

export default AccountInfoFailure;
