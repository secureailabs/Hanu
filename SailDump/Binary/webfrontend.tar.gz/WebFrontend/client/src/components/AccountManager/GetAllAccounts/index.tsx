import GetAllAccountsContainer from './GetAllAccounts.component';

export default GetAllAccountsContainer;
