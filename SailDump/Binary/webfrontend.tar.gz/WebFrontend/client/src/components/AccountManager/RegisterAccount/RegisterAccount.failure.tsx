import React from 'react';

const RegisterAccountFailure = () => {
  return (
    <>There was an error registering this account. Please try again later</>
  );
};

export default RegisterAccountFailure;
