import DeleteAccount from './DeleteAccount.container';

export default DeleteAccount;
