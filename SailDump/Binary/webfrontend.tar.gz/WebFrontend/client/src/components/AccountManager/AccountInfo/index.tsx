import AccountInfo from './AccountInfo.container';

export default AccountInfo;
