import RegisterUserFormContainer from './RegisterAccount.container';

export default RegisterUserFormContainer;
