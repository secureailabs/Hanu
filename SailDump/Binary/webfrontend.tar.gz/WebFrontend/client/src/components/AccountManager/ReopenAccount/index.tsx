import ReopenAccount from './ReopenAccount.container';

export default ReopenAccount;
