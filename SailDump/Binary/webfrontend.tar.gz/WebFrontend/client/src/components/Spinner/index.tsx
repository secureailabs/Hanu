import Spinner from './Spinner.component';
import SpinnerOnly from './SpinnerOnly.component';

export default Spinner;
export { Spinner, SpinnerOnly };
