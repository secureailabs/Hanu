import UpdateOrganization from './UpdateOrganization.container';

export default UpdateOrganization;
