import UserManagerList from './UserManagerList.component';

export default UserManagerList;