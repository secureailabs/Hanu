import { TGetAllAccountManagersSuccess } from '@redux/accountManager/accountManager.typeDefs';

export type TUserManagerList = {
  // setDatasetID(dataset: string): void;
  // Datasets: {
  //   PublishDate: string;
  //   DataOwnerGuid: string;
  //   DatasetGuid: string;
  //   DatasetName: string;
  //   Description: string;
  //   JurisdictionalLimitations: string;
  //   Keywords: string;
  //   OrganizationName: string;
  //   PrivacyLevel: number;
  //   key: string;
  // }[];
};
