import VirtualMachineList from './VirtualMachineList.component';

export default VirtualMachineList;
