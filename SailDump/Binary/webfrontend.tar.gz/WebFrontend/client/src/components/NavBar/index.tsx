import NavBar from './NavBar.container';

export default NavBar;
