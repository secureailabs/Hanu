import React from 'react';

const AcceptDigitalContractFailure = () => {
  return <p>Failure!</p>;
};

export default AcceptDigitalContractFailure;
