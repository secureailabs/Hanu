import DeprovisionDigitalContract from './DeprovisionDigitalContract.container';

export default DeprovisionDigitalContract;
