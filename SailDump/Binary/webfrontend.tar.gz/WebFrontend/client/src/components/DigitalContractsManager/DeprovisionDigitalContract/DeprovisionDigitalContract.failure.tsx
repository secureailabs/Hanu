import React from 'react';

const DeprovisionDigitalContractFailure = () => {
  return <p>Failure!</p>;
};

export default DeprovisionDigitalContractFailure;
