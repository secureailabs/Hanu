import ProvisionDigitalContract from './ProvisionDigitalContract.container';

export default ProvisionDigitalContract;
