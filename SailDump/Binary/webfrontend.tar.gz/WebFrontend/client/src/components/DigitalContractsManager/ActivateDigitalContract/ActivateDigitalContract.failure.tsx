import React from 'react';

const ActivateDigitalContractFailure = () => {
  return <p>Failure!</p>;
};

export default ActivateDigitalContractFailure;
