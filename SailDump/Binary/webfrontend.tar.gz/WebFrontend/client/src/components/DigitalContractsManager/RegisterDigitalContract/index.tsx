import RegisterDigitalContractContainer from './RegisterDigitalContract.container';

export default RegisterDigitalContractContainer;
