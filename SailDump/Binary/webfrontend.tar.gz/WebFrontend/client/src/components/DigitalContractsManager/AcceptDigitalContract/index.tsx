import AcceptDigitalContract from './AcceptDigitalContract.container';

export default AcceptDigitalContract;
