import React from 'react';

const ProvisionDigitalContractFailure = () => {
  return <p>Failure!</p>;
};

export default ProvisionDigitalContractFailure;
