import DigitalContractInfo from './DigitalContractInfo.container';

export default DigitalContractInfo;
