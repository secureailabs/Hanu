import ActivateDigitalContract from './ActivateDigitalContract.container';

export default ActivateDigitalContract;
