import DigitalContractList from './DigitalContractList.component';

export default DigitalContractList;