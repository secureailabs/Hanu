import DigitalContractListItem from './DigitalContractListItem.component';

export default DigitalContractListItem;