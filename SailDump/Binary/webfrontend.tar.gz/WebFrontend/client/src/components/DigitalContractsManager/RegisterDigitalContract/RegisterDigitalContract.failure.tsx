import React from 'react';

const RegisterDigitalContractFailure = () => {
  return (
    <>There was an error registering this dataset. Please try again later</>
  );
};

export default RegisterDigitalContractFailure;
