import Form from './Form.component';
import type { TForm } from './Form.types';

export type { TForm };
export default Form;
