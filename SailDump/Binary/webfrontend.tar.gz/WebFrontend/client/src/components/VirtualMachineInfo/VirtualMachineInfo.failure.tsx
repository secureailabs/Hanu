import React from 'react';

const VirtualMachineInfoFailure = () => {
  return <p>Failure</p>;
};

export default VirtualMachineInfoFailure;
