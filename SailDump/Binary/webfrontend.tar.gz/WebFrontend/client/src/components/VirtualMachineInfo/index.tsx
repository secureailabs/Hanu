import DigitalContractInfo from './VirtualMachineInfo.container';

export default DigitalContractInfo;
