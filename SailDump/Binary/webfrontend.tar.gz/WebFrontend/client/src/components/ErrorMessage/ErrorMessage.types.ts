export type TErrorMessageProps = {
  errorMessage: string;
};
