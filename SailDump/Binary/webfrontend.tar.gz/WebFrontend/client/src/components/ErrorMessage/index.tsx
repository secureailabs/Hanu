import ErrorMessage from './ErrorMessage.component';
import type {TErrorMessageProps} from './ErrorMessage.types';


export default ErrorMessage;
export type {TErrorMessageProps};