import React from 'react';

const DeleteAzureTemplateFailure = () => {
  return <p>There was an error deleting this template, please try again later.</p>;
};

export default DeleteAzureTemplateFailure;
