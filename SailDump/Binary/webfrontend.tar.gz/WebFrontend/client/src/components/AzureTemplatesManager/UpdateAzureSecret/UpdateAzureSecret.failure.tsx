import React from 'react';

const UpdateAzureSecretFailure = () => {
  return <p>Failure!</p>;
};

export default UpdateAzureSecretFailure;
