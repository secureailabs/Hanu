import React from 'react';

const UpdateOrganizationFailure = () => {
  return <>Failure</>;
};

export default UpdateOrganizationFailure;
