import React from 'react';

const AzureTemplateInfoFailure = () => {
  return <p>There was an error fetching the Azure template information, please try again later.</p>;
};

export default AzureTemplateInfoFailure;
