import AzureTemplatesList from './AzureTemplatesList.component';

export default AzureTemplatesList;
