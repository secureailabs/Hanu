import React from 'react';

const AccountManagerFailure = () => {
  return <p>There was an error fetching users. Please try again later</p>;
};

export default AccountManagerFailure;
