import EditAzureTemplateContainer from './EditAzureTemplate.container';

export default EditAzureTemplateContainer;
