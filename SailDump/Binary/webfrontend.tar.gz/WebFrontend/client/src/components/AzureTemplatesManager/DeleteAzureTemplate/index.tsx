import DeleteAzureTemplate from './DeleteAzureTemplate.container';

export default DeleteAzureTemplate;
