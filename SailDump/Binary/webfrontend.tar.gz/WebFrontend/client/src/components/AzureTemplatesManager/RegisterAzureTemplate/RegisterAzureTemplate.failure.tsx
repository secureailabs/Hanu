import React from 'react';

const RegisterAzureTemplateFailure = () => {
  return (
    <>There was an error registering this template. Please try again later.</>
  );
};

export default RegisterAzureTemplateFailure;
