import RegisterAzureTemplate from './RegisterAzureTemplate.container';

export default RegisterAzureTemplate;
