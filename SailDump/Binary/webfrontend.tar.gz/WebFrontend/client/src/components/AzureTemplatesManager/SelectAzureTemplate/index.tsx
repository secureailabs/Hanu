import SelectAzureTemplateContainer from './SelectAzureTemplate.container';

export default SelectAzureTemplateContainer;
