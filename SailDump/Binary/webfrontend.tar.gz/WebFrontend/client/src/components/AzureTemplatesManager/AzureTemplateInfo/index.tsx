import AzureTemplateInfo from './AzureTemplateInfo.container';

export default AzureTemplateInfo;
