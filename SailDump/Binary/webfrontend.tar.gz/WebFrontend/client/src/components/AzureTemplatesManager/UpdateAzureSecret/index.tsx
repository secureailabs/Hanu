import UpdateAzureSecret from './UpdateAzureSecret.container';

export default UpdateAzureSecret;
