import UpdateAzureTemplate from './UpdateAzureTemplate.container';

export default UpdateAzureTemplate;
