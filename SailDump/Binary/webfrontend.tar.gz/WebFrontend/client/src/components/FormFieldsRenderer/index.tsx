import FormRenderer from './FormFieldsRenderer.component';
import type { TFormFieldsRenderer } from './FormFieldsRenderer.types';

export type { TFormFieldsRenderer };
export default FormRenderer;
