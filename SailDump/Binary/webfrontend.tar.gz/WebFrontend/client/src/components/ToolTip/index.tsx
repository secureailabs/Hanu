import type {TTooltipProps} from './ToolTip.types';
import ToolTip from './ToolTip.component';

export default ToolTip;
export type { TTooltipProps };