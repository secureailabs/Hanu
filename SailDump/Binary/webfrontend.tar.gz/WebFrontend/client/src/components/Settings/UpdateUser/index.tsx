import UpdateOrganization from './UpdateUser.container';

export default UpdateOrganization;
