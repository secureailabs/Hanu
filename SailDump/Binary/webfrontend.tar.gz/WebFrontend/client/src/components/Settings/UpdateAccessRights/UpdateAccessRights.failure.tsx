import React from 'react';

const UpdateAccessRightsFailure = () => {
  return <></>;
};

export default UpdateAccessRightsFailure;
