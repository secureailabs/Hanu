import UpdatePassword from './UpdatePassword.container';

export default UpdatePassword;
