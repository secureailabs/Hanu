import React from 'react';

const UpdateAccessRightsSuccess = () => {
  return <></>;
};

export default UpdateAccessRightsSuccess;
