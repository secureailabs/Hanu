import MultiPartForm from './MultiPartForm.component';

export default MultiPartForm;
