import DatasetInfo from './DatasetInfo.container';

export default DatasetInfo;
