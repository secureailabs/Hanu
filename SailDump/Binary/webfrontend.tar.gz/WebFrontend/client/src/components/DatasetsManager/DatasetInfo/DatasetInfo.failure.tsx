import React from 'react';

const DigitalContractInfoFailure = () => {
  return <p>Failure</p>;
};

export default DigitalContractInfoFailure;
