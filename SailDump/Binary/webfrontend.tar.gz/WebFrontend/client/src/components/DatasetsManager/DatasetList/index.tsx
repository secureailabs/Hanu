import DigitalContractList from './DatasetList.component';

export default DigitalContractList;