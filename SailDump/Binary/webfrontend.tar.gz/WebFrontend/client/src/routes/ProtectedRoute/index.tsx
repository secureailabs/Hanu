import ProtectedRouteContainer from './ProtectedRoute.container';

export default ProtectedRouteContainer;
