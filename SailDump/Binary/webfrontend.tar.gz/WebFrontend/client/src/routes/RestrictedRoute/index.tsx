import RestrictedRouteContainer from './RestrictedRoute.container';

export default RestrictedRouteContainer;
